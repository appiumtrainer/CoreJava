package corejava.examples;

public class IfThen_Statement {

	public static void main(String[] args) {
		String sDay = "Sunday";
		int iDay = 7;
		
		if(sDay.equals("Sunday")){
			System.out.println("Today is Sunday");
		}
		
		if(iDay==7){
			System.out.println("Today is Sunday");
		}
	}
}
