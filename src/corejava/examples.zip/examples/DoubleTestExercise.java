package corejava.examples;

public class DoubleTestExercise {

	public static void main(String[] args) {
		//Use the double keyword to declare decimal variable
		double PI;

		//Initialize the double variable with value 'P'
       PI = 3.14159;

      //Print the value of double variable
        System.out.print("Floting point vale is " + PI);

	}

}
