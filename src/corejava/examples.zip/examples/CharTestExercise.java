package corejava.examples;

public class CharTestExercise {

	public static void main(String[] args) {
		//Use the char keyword to declare character variable
        char a;

        //Initialize the char variable with value 'P'
         a = '0';

        //Print the value of char variable
      	System.out.println("Value of char is : " +  a);

	}

}